const express = require('express');
const router = express.Router();

const CarroController = require('./controllers/CarroControllers');

router.get('/carros', CarroController.buscarTodos);

module.exports = router;